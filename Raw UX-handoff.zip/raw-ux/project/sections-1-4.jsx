/* Sections 1–4: Hero, Philosophy, Selected Work, Process — v3 with textures */

const CREAM_TEXTURE = 'images/cream-paper.png';
const GREEN_TEXTURE = 'images/green-fabric.png';

const creamBg = { backgroundColor: '#F5F0E8', backgroundImage: `url(${CREAM_TEXTURE})`, backgroundSize: 'cover', backgroundPosition: 'center' };
const greenBg = { backgroundImage: `url(${GREEN_TEXTURE})`, backgroundSize: 'cover', backgroundPosition: 'center' };

const TornEdge = ({ color = '#F5F0E8', flip = false, height = 40 }) => (
  <div style={{ width: '100%', height, overflow: 'hidden', transform: flip ? 'scaleY(-1)' : 'none', position: 'relative', zIndex: 2 }}>
    <svg viewBox="0 0 1440 40" preserveAspectRatio="none" style={{ width: '100%', height: '100%', display: 'block' }}>
      <path d="M0,0 L0,20 Q30,35 60,22 T120,28 T180,18 T240,30 T300,20 T360,32 T420,22 T480,28 T540,18 T600,30 T660,24 T720,32 T780,20 T840,28 T900,22 T960,30 T1020,18 T1080,26 T1140,32 T1200,20 T1260,28 T1320,22 T1380,30 L1440,24 L1440,0 Z" fill={color} />
    </svg>
  </div>
);

const Dot = () => (
  <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', backgroundColor: '#C0452A', flexShrink: 0 }}></span>
);

const Pagination = ({ label, num, total = 7, light = false }) => (
  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: light ? '#9A9590' : '#6B6560', display: 'flex', alignItems: 'center', gap: 10, marginBottom: 32 }}>
    <Dot /> <span>{label}</span> <span style={{ color: '#C0452A' }}>{num} OF {total}</span>
  </div>
);

const Headline = ({ text, light = false }) => {
  const endsWithPeriod = text && text.endsWith('.');
  const displayText = endsWithPeriod ? text.slice(0, -1) : (text || '');
  return (
    <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(2.5rem, 5vw, 5rem)', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.0, color: light ? '#FAF7F2' : '#1A1A1A', margin: 0 }}>
      {displayText}{endsWithPeriod && <span style={{ color: '#C0452A' }}>.</span>}
    </h2>
  );
};

const AnnotationCard = ({ label, value, dark = true, style = {} }) => (
  <div style={{ backgroundColor: dark ? '#1E1E1E' : '#E8DFD0', color: dark ? '#E5E5E5' : '#1A1A1A', padding: '16px 20px', fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', lineHeight: 1.6, boxShadow: '0 2px 8px rgba(0,0,0,0.15)', ...style }}>
    <div style={{ color: '#6B6560', marginBottom: 4 }}>{label}</div>
    {value && <div style={{ fontSize: '0.8rem' }}>{value}</div>}
  </div>
);

const BtnPrimary = ({ children, style = {}, fullWidth = false }) => (
  <button style={{ backgroundColor: '#C0452A', color: '#FAF7F2', border: 'none', borderRadius: 999, padding: '14px 28px', fontFamily: "'Public Sans', sans-serif", fontSize: '0.9rem', cursor: 'pointer', width: fullWidth ? '100%' : 'auto', ...style }}>{children}</button>
);

const BtnOutline = ({ children, style = {} }) => (
  <button style={{ backgroundColor: 'transparent', color: '#C0452A', border: '1px solid #C0452A', borderRadius: 999, padding: '14px 28px', fontFamily: "'Public Sans', sans-serif", fontSize: '0.9rem', cursor: 'pointer', ...style }}>{children}</button>
);

const Monogram = ({ light = false }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
    <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.8rem', color: light ? '#FAF7F2' : '#1A1A1A', lineHeight: 1 }}>R <span style={{ color: '#C0452A' }}>/</span> U</div>
    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.6rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#6B6560', lineHeight: 1.6 }}>
      We Design . Build . Ship
    </div>
  </div>
);

const FigLabel = ({ text, light = true }) => (
  <div style={{ position: 'absolute', bottom: 12, left: 16, fontFamily: "'JetBrains Mono', monospace", fontSize: '0.6rem', color: light ? 'rgba(255,255,255,0.6)' : '#6B6560', letterSpacing: '0.12em', textTransform: 'uppercase' }}>{text}</div>
);

/* ─── SECTION 1: HERO ─── */
const HeroSection = ({ tweaks }) => {
  const v = tweaks.variation;
  const showBold21 = v === 'bold';

  return (
    <section data-screen-label="01 Hero" style={{ ...creamBg, minHeight: '100vh', position: 'relative', overflow: 'hidden' }}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '28px 64px', position: 'relative', zIndex: 10 }}>
        <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.4rem', color: '#1A1A1A' }}>Raw UX</div>
        <div style={{ display: 'flex', gap: 32, fontFamily: "'Public Sans', sans-serif", fontSize: '0.85rem', letterSpacing: '0.06em', textTransform: 'uppercase', color: '#1A1A1A' }}>
          <span style={{ cursor: 'pointer' }}>Work</span>
          <span style={{ cursor: 'pointer' }}>Process</span>
          <span style={{ cursor: 'pointer' }}>Capabilities</span>
          <span style={{ cursor: 'pointer' }}>Contact</span>
        </div>
      </nav>

      <div style={{ display: 'flex', padding: '80px 64px 120px', gap: 40, position: 'relative' }}>
        <div style={{ width: '40%', flexShrink: 0, position: 'relative', zIndex: 5 }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#6B6560', marginBottom: 40, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Dot /> Design. AI. Product. Leadership.
          </div>

          {showBold21 ? (
            <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(3rem, 5.5vw, 5.5rem)', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.0, color: '#1A1A1A', margin: '0 0 32px 0', maxWidth: 520 }}>
              <span style={{ display: 'block', fontFamily: "'JetBrains Mono', monospace", fontSize: '6rem', color: '#C0452A', letterSpacing: '-0.04em', lineHeight: 0.9, marginBottom: 12 }}>21</span>
              days from idea to shipped product<span style={{ color: '#C0452A' }}>.</span>
            </h1>
          ) : (
            <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(3rem, 5.5vw, 5.5rem)', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.0, color: '#1A1A1A', margin: '0 0 32px 0', maxWidth: 520 }}>
              {v === 'understated'
                ? <React.Fragment>Your product, designed and shipped<span style={{ color: '#C0452A' }}>.</span></React.Fragment>
                : <React.Fragment>Your MVP, shipped in 21 days<span style={{ color: '#C0452A' }}>.</span></React.Fragment>
              }
            </h1>
          )}

          <p style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '1.1rem', lineHeight: 1.65, color: '#6B6560', maxWidth: 420, margin: '0 0 40px 0' }}>
            We design, build, and deploy production products in 3 weeks. Not mockups. Not concepts. Shipped.
          </p>
          <div style={{ display: 'flex', gap: 16 }}>
            <BtnPrimary>See the work</BtnPrimary>
            <BtnOutline>Start your 21 days</BtnOutline>
          </div>

          <div style={{ position: 'absolute', bottom: -40, left: 0 }}>
            <Monogram />
          </div>
        </div>

        {/* Right: Dense Collage */}
        <div style={{ width: '60%', position: 'relative', minHeight: 520 }}>
          {/* Layer 1: Large dark green block */}
          <div style={{ position: 'absolute', top: 0, right: 0, width: '72%', height: 320, ...greenBg, zIndex: 1 }}>
            <FigLabel text="fig. 01 / landing page" />
          </div>
          {/* Layer 2: Parchment block overlapping */}
          <div style={{ position: 'absolute', top: 60, left: 0, width: '40%', height: 220, backgroundColor: '#E8DFD0', zIndex: 2 }}>
            <FigLabel text="fig. 02 / mobile app" light={false} />
          </div>
          {/* Layer 3: Charcoal block */}
          <div style={{ position: 'absolute', top: 260, right: 30, width: '45%', height: 200, backgroundColor: '#1E1E1E', zIndex: 3 }}>
            <FigLabel text="fig. 03 / dashboard" />
          </div>
          {/* Layer 4: Small green block overlapping charcoal */}
          <div style={{ position: 'absolute', top: 340, left: '15%', width: '30%', height: 140, ...greenBg, zIndex: 2 }}>
            <FigLabel text="fig. 04 / design system" />
          </div>
          {/* Layer 5: Thin parchment strip */}
          <div style={{ position: 'absolute', top: 180, right: '10%', width: '25%', height: 100, backgroundColor: '#E8DFD0', zIndex: 4 }}></div>
          {/* Layer 6: Small charcoal block at top-left */}
          <div style={{ position: 'absolute', top: -10, left: '25%', width: '20%', height: 90, backgroundColor: '#1E1E1E', zIndex: 3 }}></div>

          {/* Annotation cards ON TOP of blocks */}
          <AnnotationCard label="COHERENCE" value="0.92" style={{ position: 'absolute', top: 30, left: '32%', zIndex: 10 }} />
          <AnnotationCard label="SIGNAL / NOISE" value="HIGH" dark={false} style={{ position: 'absolute', top: 220, right: 10, zIndex: 10 }} />
          <AnnotationCard label="EXPERIMENT 01" value="AI INTERFACE PATTERN" style={{ position: 'absolute', bottom: 40, left: 40, zIndex: 10 }} />

          {showBold21 && (
            <div style={{ position: 'absolute', top: 140, left: '5%', fontFamily: "'JetBrains Mono', monospace", fontSize: '4rem', color: 'rgba(192,69,42,0.08)', letterSpacing: '-0.04em', zIndex: 0 }}>21</div>
          )}
        </div>
      </div>
      <TornEdge color="#F5F0E8" />
    </section>
  );
};

/* ─── SECTION 2: PHILOSOPHY ─── */
const PhilosophySection = ({ tweaks }) => {
  const v = tweaks.variation;
  const showCollage = v !== 'understated';
  const showExtra = v === 'bold';
  const pillars = [
    { num: '01', title: 'Design Systems', desc: 'Scalable foundations that unify product language across every surface and state.' },
    { num: '02', title: 'AI Product Design', desc: 'Interfaces for models, agents, and intelligent workflows that feel human.' },
    { num: '03', title: 'Design Leadership', desc: 'Building teams, rituals, and culture that ship with intention and clarity.' },
    { num: '04', title: 'Full-Stack Craft', desc: 'From research to code. Design that ships, not decks that sit.' },
  ];
  const headlines = {
    understated: 'Clear thinking produces fast shipping.',
    balanced: 'We ship fast because we think clearly.',
    bold: 'Speed is a byproduct of clarity.',
  };

  return (
    <section data-screen-label="02 Philosophy" style={{ ...creamBg, backgroundColor: '#FAF7F2', padding: '120px 64px', position: 'relative' }}>
      <div style={{ display: 'flex', gap: 60 }}>
        <div style={{ width: '55%' }}>
          <Pagination label="PHILOSOPHY" num="2" />
          <Headline text={headlines[v]} />
          <p style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '1.05rem', lineHeight: 1.65, color: '#6B6560', maxWidth: 480, margin: '28px 0 48px 0' }}>
            The 21 days work because the process is tight, not because corners are cut. We treat every product decision as a hypothesis, every interface as evidence of intention.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32 }}>
            {pillars.map(p => (
              <div key={p.num}>
                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.8rem', color: '#C0452A', marginBottom: 8 }}>{p.num}</div>
                <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.25rem', color: '#1A1A1A', marginBottom: 6 }}>{p.title}</div>
                <div style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '0.9rem', lineHeight: 1.55, color: '#6B6560' }}>{p.desc}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 16, marginTop: 48 }}>
            <BtnPrimary>See the work</BtnPrimary>
            <BtnOutline>Our process</BtnOutline>
          </div>
        </div>

        <div style={{ width: '45%', position: 'relative', minHeight: 400 }}>
          <div style={{ position: 'absolute', top: 40, right: 0, width: '80%', height: 260, ...greenBg }}>
            <FigLabel text="fig. 04 / design system tokens" />
          </div>
          {showCollage && (
            <div style={{ position: 'absolute', top: 280, left: 20, width: '55%', height: 140, backgroundColor: '#E8DFD0' }}></div>
          )}
          <AnnotationCard label="OBSERVATION" value="PATTERN RECOGNITION IS DESIGN" dark={false} style={{ position: 'absolute', top: 0, left: 0, zIndex: 5 }} />
          {showExtra && (
            <AnnotationCard label="STUDIO NOTE" value="21 DAYS / ZERO COMPROMISE" style={{ position: 'absolute', bottom: 40, right: 20, zIndex: 5 }} />
          )}
        </div>
      </div>
    </section>
  );
};

/* ─── SECTION 3: SELECTED WORK ─── */
const WorkSection = ({ tweaks }) => {
  const v = tweaks.variation;
  const showAnnotations = v !== 'understated';
  const headlines = {
    understated: 'Shipped.',
    balanced: 'What we shipped.',
    bold: 'What we shipped.',
  };

  return (
    <section data-screen-label="03 Selected Work" style={{ ...creamBg, padding: '120px 64px', position: 'relative' }}>
      <Pagination label="SELECTED WORK" num="3" />
      <Headline text={headlines[v]} />
      <p style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '1.05rem', lineHeight: 1.65, color: '#6B6560', maxWidth: 520, margin: '24px 0 56px 0' }}>
        Products we designed, built, and deployed. Not concepts. Not mockups. Live and running.
      </p>

      <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>
        {/* Card 1: Large — 60% */}
        <div style={{ flex: '1.5', position: 'relative' }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.8rem', color: '#C0452A', marginBottom: 12 }}>01</div>
          <div style={{ height: 400, position: 'relative', marginBottom: 16, ...greenBg }}>
            {showAnnotations && (
              <div style={{ position: 'absolute', bottom: 16, right: 16, backgroundColor: '#1E1E1E', padding: '12px 16px', fontFamily: "'JetBrains Mono', monospace", fontSize: '0.65rem', color: '#E5E5E5', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                <div style={{ color: '#6B6560', marginBottom: 4 }}>SHIPPED</div>
                <div>CONFIDENCE 0.96</div>
              </div>
            )}
            <FigLabel text="fig. 05 / SaaS dashboard" />
          </div>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.4rem', color: '#1A1A1A', marginBottom: 6 }}>SaaS Analytics Dashboard</div>
          <div style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '0.9rem', color: '#6B6560' }}>Data-dense health insights platform with AI-powered pattern recognition.</div>
        </div>

        {/* Cards 2 & 3: Stacked — 40% */}
        <div style={{ flex: '1', display: 'flex', flexDirection: 'column', gap: 24 }}>
          <div>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.8rem', color: '#C0452A', marginBottom: 12 }}>02</div>
            <div style={{ height: 185, position: 'relative', marginBottom: 12, backgroundColor: '#E8DFD0' }}>
              <FigLabel text="fig. 06 / mobile app" light={false} />
            </div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.15rem', color: '#1A1A1A', marginBottom: 4 }}>Mobile Health Companion</div>
            <div style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '0.85rem', color: '#6B6560' }}>Symptom tracking app with AI insights and doctor-ready reports.</div>
          </div>
          <div>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.8rem', color: '#C0452A', marginBottom: 12 }}>03</div>
            <div style={{ height: 185, position: 'relative', marginBottom: 12, backgroundColor: '#1E1E1E' }}>
              <FigLabel text="fig. 07 / marketplace" />
            </div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.15rem', color: '#1A1A1A', marginBottom: 4 }}>Automation Marketplace</div>
            <div style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '0.85rem', color: '#6B6560' }}>Two-sided platform connecting businesses with pre-built automation packages.</div>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 48 }}>
        <BtnOutline>View all work &rarr;</BtnOutline>
      </div>
    </section>
  );
};

/* ─── SECTION 4: PROCESS ─── */
const ProcessSection = ({ tweaks }) => {
  const v = tweaks.variation;
  const showBold = v === 'bold';
  const headlines = {
    understated: 'How we work.',
    balanced: 'How we ship in 21 days.',
    bold: 'How we ship in 21 days.',
  };
  const phases = [
    { week: 'Week 1', title: 'Discover + Design', desc: 'Research, decisions, and rapid prototyping. We understand the problem and design the solution in the first 7 days.' },
    { week: 'Week 2', title: 'Build', desc: 'Production code. Real data. Integrations. The product takes shape with working functionality.' },
    { week: 'Week 3', title: 'Ship', desc: 'Polish, review, deploy. Live on day 21. Every detail intentional, every interaction tested.' },
  ];
  const panelStyles = [
    { ...greenBg },
    { backgroundColor: '#1E1E1E' },
    { backgroundColor: '#E8DFD0', backgroundImage: `url(${CREAM_TEXTURE})`, backgroundSize: 'cover' },
  ];

  return (
    <section data-screen-label="04 Process" style={{ ...creamBg, backgroundColor: '#FAF7F2', padding: '120px 64px', position: 'relative' }}>
      <Pagination label="PROCESS" num="4" />
      <div style={{ maxWidth: 560, marginBottom: 56 }}>
        <Headline text={headlines[v]} />
        <p style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '1.05rem', lineHeight: 1.65, color: '#6B6560', margin: '24px 0 0 0' }}>
          Three weeks. From first conversation to deployed product.
        </p>
      </div>

      {/* Image strip: 3 textured panels */}
      <div style={{ display: 'flex', width: '100%', height: 220, marginBottom: 48 }}>
        {panelStyles.map((s, i) => (
          <div key={i} style={{ flex: 1, position: 'relative', ...s }}>
            <div style={{ position: 'absolute', bottom: 14, left: 16, fontFamily: "'JetBrains Mono', monospace", fontSize: '0.6rem', color: i === 2 ? '#6B6560' : 'rgba(255,255,255,0.5)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
              week 0{i + 1}
            </div>
          </div>
        ))}
      </div>

      {/* Three columns */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 40 }}>
        {phases.map((p, i) => (
          <div key={i}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}><Dot /></div>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#C0452A', marginBottom: 8 }}>{p.week}</div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.3rem', color: '#1A1A1A', marginBottom: 10 }}>{p.title}</div>
            <div style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '0.9rem', lineHeight: 1.55, color: '#6B6560', marginBottom: 16 }}>{p.desc}</div>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', color: '#C0452A', letterSpacing: '0.06em', cursor: 'pointer' }}>&rarr;</span>
          </div>
        ))}
      </div>

      {v !== 'understated' && (
        <AnnotationCard label="METHOD" value={showBold ? 'IDEA TO DEPLOYED IN 21 DAYS' : 'INSIGHT TO ITERATION'} style={{ position: 'absolute', top: 100, right: 64, zIndex: 5 }} />
      )}
    </section>
  );
};

Object.assign(window, { TornEdge, Dot, Pagination, Headline, AnnotationCard, BtnPrimary, BtnOutline, Monogram, FigLabel, creamBg, greenBg, CREAM_TEXTURE, GREEN_TEXTURE, HeroSection, PhilosophySection, WorkSection, ProcessSection });
