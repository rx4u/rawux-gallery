/* Sections 5–7: Capabilities, Tools, Contact+Intake — v3 with textures */

/* ─── SECTION 5: CAPABILITIES ─── */
const CapabilitiesSection = ({ tweaks }) => {
  const v = tweaks.variation;
  const showMetrics = v !== 'understated';
  const headlines = {
    understated: 'What we build.',
    balanced: 'What we ship.',
    bold: 'What we ship in 21 days.',
  };

  const capabilities = [
    { title: 'AI Product Design', desc: 'Interfaces for LLMs, agents, and intelligent workflows.', metric: 'CONFIDENCE 0.96' },
    { title: 'SaaS Platforms', desc: 'Dashboards, admin panels, and data-dense products.', metric: 'SIGNAL / NOISE HIGH' },
    { title: 'Landing Pages', desc: 'Narrative-driven pages that convert intent into action.', metric: 'CONVERSION LAYER' },
    { title: 'Mobile Apps', desc: 'Touch-native experiences from onboarding to retention.', metric: 'PLATFORM NATIVE' },
    { title: 'Design Systems', desc: 'Scalable foundations that keep products coherent at scale.', metric: '200+ COMPONENTS' },
    { title: 'Marketplaces', desc: 'Multi-sided platforms with booking flows and role-based experiences.', metric: '5 TEAMS LED' },
  ];

  // Asymmetric: first card spans 2 cols
  const gridAreas = [
    { gridColumn: 'span 2', gridRow: 'span 1' },
    { gridColumn: 'span 1', gridRow: 'span 1' },
    { gridColumn: 'span 1', gridRow: 'span 1' },
    { gridColumn: 'span 1', gridRow: 'span 1' },
    { gridColumn: 'span 1', gridRow: 'span 1' },
    { gridColumn: 'span 2', gridRow: 'span 1' },
  ];

  return (
    <section data-screen-label="05 Capabilities" style={{ backgroundColor: '#1E1E1E', padding: '120px 64px', position: 'relative' }}>
      <Pagination label="CAPABILITIES" num="5" light={true} />
      <div style={{ marginBottom: 56 }}>
        <Headline text={headlines[v]} light={true} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        {capabilities.map((c, i) => (
          <div key={i} style={{
            ...gridAreas[i],
            ...greenBg,
            padding: '32px',
            display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
            minHeight: 180,
          }}>
            <div>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(229,229,229,0.5)', marginBottom: 12 }}>{c.title}</div>
              <div style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '0.9rem', lineHeight: 1.55, color: '#E5E5E5' }}>{c.desc}</div>
            </div>
            {showMetrics && (
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.65rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#C0452A', marginTop: 20 }}>{c.metric}</div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
};

/* ─── SECTION 6: TOOLS ─── */
const ToolsSection = ({ tweaks }) => {
  const v = tweaks.variation;
  const designTools = ['Figma', 'Claude Design', 'Framer'];
  const engTools = ['Next.js', 'Supabase', 'Tailwind', 'Vercel', 'Claude Code', 'Claude API'];
  const headlines = {
    understated: 'The stack behind the speed.',
    balanced: 'The stack behind the speed.',
    bold: 'Why 21 days is possible.',
  };

  return (
    <section data-screen-label="06 Tools" style={{ ...creamBg, backgroundColor: '#FAF7F2', padding: '120px 64px', position: 'relative' }}>
      <Pagination label="TOOLS & STACK" num="6" />
      <div style={{ display: 'flex', gap: 80 }}>
        <div style={{ flex: 1 }}>
          <Headline text={headlines[v]} />
          <div style={{ marginTop: 56 }}>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#C0452A', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}><Dot /> Design</div>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 48 }}>
              {designTools.map(t => (
                <div key={t} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.8rem', letterSpacing: '0.06em', color: '#1A1A1A', padding: '10px 18px', backgroundColor: 'rgba(245,240,232,0.8)' }}>{t}</div>
              ))}
            </div>

            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#C0452A', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}><Dot /> Engineering</div>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              {engTools.map(t => (
                <div key={t} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.8rem', letterSpacing: '0.06em', color: '#1A1A1A', padding: '10px 18px', backgroundColor: 'rgba(245,240,232,0.8)' }}>{t}</div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ width: 280, flexShrink: 0, alignSelf: 'center' }}>
          <AnnotationCard label="MODERN STACK" value="IDEA TO PRODUCTION IN 21 DAYS" dark={true} />
        </div>
      </div>
    </section>
  );
};

/* ─── SECTION 7: CONTACT + INTAKE ─── */
const ContactSection = ({ tweaks }) => {
  const v = tweaks.variation;
  const [form, setForm] = React.useState({ name: '', email: '', brief: '', types: [], budget: '', timeline: '' });

  const toggleType = (t) => {
    setForm(prev => ({
      ...prev,
      types: prev.types.includes(t) ? prev.types.filter(x => x !== t) : [...prev.types, t]
    }));
  };

  const productTypes = ['Web App', 'Mobile App', 'Landing Page', 'Dashboard', 'Marketplace', 'Other'];
  const budgets = ['$3K-5K', '$5K-10K', '$10K-20K', '$20K+'];
  const timelines = ['ASAP', 'This Month', 'Next Month', 'Exploring'];

  const pillStyle = (selected) => ({
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: '0.7rem',
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    padding: '10px 18px',
    borderRadius: 999,
    border: selected ? '1px solid #C0452A' : '1px solid rgba(229,229,229,0.25)',
    backgroundColor: selected ? '#C0452A' : 'transparent',
    color: selected ? '#FAF7F2' : 'rgba(229,229,229,0.7)',
    cursor: 'pointer',
    transition: 'all 0.15s',
  });

  const inputStyle = {
    fontFamily: "'Public Sans', sans-serif",
    fontSize: '0.95rem',
    color: '#E5E5E5',
    backgroundColor: 'transparent',
    border: 'none',
    borderBottom: '1px solid rgba(229,229,229,0.2)',
    padding: '12px 0',
    width: '100%',
    outline: 'none',
  };

  const labelStyle = {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: '0.65rem',
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: 'rgba(229,229,229,0.45)',
    marginBottom: 8,
    display: 'block',
  };

  const links = [
    { label: 'Dribbble', href: '#' },
    { label: 'LinkedIn', href: '#' },
    { label: 'X', href: '#' },
  ];

  return (
    <section data-screen-label="07 Contact" style={{ backgroundColor: '#1E1E1E', padding: '120px 64px 80px', position: 'relative' }}>
      <Pagination label="CONTACT" num="7" light={true} />

      <div style={{ display: 'flex', gap: 64, alignItems: 'flex-start' }}>
        {/* Left: CTA */}
        <div style={{ width: '40%', flexShrink: 0 }}>
          <Headline text="Start your 21 days." light={true} />
          <p style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '1.05rem', lineHeight: 1.65, color: 'rgba(229,229,229,0.65)', maxWidth: 380, margin: '24px 0 32px 0' }}>
            Tell us what you want to build. We get back within 24 hours.
          </p>
          <a href="mailto:hello@rawux.studio" style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '1.05rem', color: '#E5E5E5', textDecoration: 'none', borderBottom: '1px solid #6B6560', display: 'inline-block', marginBottom: 28 }}>hello@rawux.studio</a>
          <div style={{ display: 'flex', gap: 24 }}>
            {links.map(l => (
              <a key={l.label} href={l.href} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#6B6560', textDecoration: 'none', cursor: 'pointer' }}>{l.label}</a>
            ))}
          </div>
        </div>

        {/* Right: Intake Form */}
        <div style={{ flex: 1, backgroundColor: '#2A2A2A', padding: '40px 36px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 36 }}>
            <Dot />
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#E5E5E5' }}>Project Brief</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
            <div>
              <label style={labelStyle}>Your Name</label>
              <input type="text" style={inputStyle} value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
            </div>
            <div>
              <label style={labelStyle}>Email</label>
              <input type="email" style={inputStyle} value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
            </div>
            <div>
              <label style={labelStyle}>What are we building?</label>
              <textarea rows={3} style={{ ...inputStyle, resize: 'vertical' }} placeholder="An AI dashboard, a SaaS platform, a marketplace..." value={form.brief} onChange={e => setForm({...form, brief: e.target.value})} />
            </div>
            <div>
              <label style={labelStyle}>Product Type</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
                {productTypes.map(t => (
                  <button key={t} style={pillStyle(form.types.includes(t))} onClick={() => toggleType(t)}>{t}</button>
                ))}
              </div>
            </div>
            <div>
              <label style={labelStyle}>Budget Range</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
                {budgets.map(b => (
                  <button key={b} style={pillStyle(form.budget === b)} onClick={() => setForm({...form, budget: b})}>{b}</button>
                ))}
              </div>
            </div>
            <div>
              <label style={labelStyle}>Timeline</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
                {timelines.map(t => (
                  <button key={t} style={pillStyle(form.timeline === t)} onClick={() => setForm({...form, timeline: t})}>{t}</button>
                ))}
              </div>
            </div>

            <BtnPrimary fullWidth={true} style={{ marginTop: 8 }}>Send brief</BtnPrimary>

            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.6rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'rgba(229,229,229,0.3)', textAlign: 'center' }}>
              We respond within 24 hours.
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ marginTop: 120, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderTop: '1px solid #2D3830', paddingTop: 28 }}>
        <Monogram light={true} />
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.6rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#6B6560' }}>
          &copy; 2026 Raw UX
        </div>
      </div>
    </section>
  );
};

Object.assign(window, { CapabilitiesSection, ToolsSection, ContactSection });
