/* Sections 5–8: Process, Skills, Tools, Contact */

/* ─── SECTION 5: PROCESS ─── */
const ProcessSection = ({ tweaks }) => {
  const density = tweaks.density;
  const phases = [
    { title: 'Discover', desc: 'Listening, research, and pattern finding. Understanding the problem before touching pixels.' },
    { title: 'Design', desc: 'Fast prototypes and testing ideas. Moving from insight to artifact at speed.' },
    { title: 'Review', desc: 'Challenging assumptions through critique. Pressure-testing every decision.' },
    { title: 'Ship', desc: 'Polish and intentional details. The last 10% is where craft lives.' },
  ];
  const stripColors = ['#2D3830', '#1E1E1E', '#E8DFD0', '#2D3830'];

  return (
    <section data-screen-label="05 Process" style={{ backgroundColor: '#F5F0E8', padding: '120px 64px', position: 'relative' }}>
      <Pagination label="PROCESS" num="5" />
      <div style={{ maxWidth: 560, marginBottom: 56 }}>
        <Headline text="How I work." />
        <p style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '1.05rem', lineHeight: 1.65, color: '#6B6560', margin: '24px 0 0 0' }}>
          Curiosity first, then craft. Moving from insight to iteration with rigor and speed.
        </p>
      </div>

      {/* Image strip with torn edges */}
      <div style={{ display: 'flex', width: '100%', height: density === 'restrained' ? 160 : 200, marginBottom: 48, position: 'relative' }}>
        {stripColors.map((c, i) => (
          <div key={i} style={{ flex: 1, backgroundColor: c, position: 'relative' }}>
            {i < 3 && (
              <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: 3, background: `linear-gradient(to bottom, ${c}, #F5F0E8 30%, ${c} 45%, #F5F0E8 60%, ${c} 75%, #F5F0E8)`, zIndex: 2 }}></div>
            )}
            <div style={{ position: 'absolute', bottom: 10, left: 12, fontFamily: "'JetBrains Mono', monospace", fontSize: '0.55rem', color: c === '#E8DFD0' ? '#6B6560' : 'rgba(255,255,255,0.35)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
              phase 0{i + 1}
            </div>
          </div>
        ))}
      </div>

      {/* Four columns */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 32 }}>
        {phases.map((p, i) => (
          <div key={i}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}><Dot /></div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.3rem', color: '#1A1A1A', marginBottom: 10 }}>{p.title}</div>
            <div style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '0.9rem', lineHeight: 1.55, color: '#6B6560', marginBottom: 16 }}>{p.desc}</div>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', color: '#C0452A', letterSpacing: '0.06em', cursor: 'pointer' }}>&rarr;</span>
          </div>
        ))}
      </div>

      {density === 'dense' && (
        <AnnotationCard label="METHOD" value="INSIGHT TO ITERATION" style={{ position: 'absolute', top: 100, right: 64, zIndex: 5 }} />
      )}
    </section>
  );
};

/* ─── SECTION 6: SKILLS ─── */
const SkillsSection = ({ tweaks }) => {
  const density = tweaks.density;
  const capabilities = [
    { title: 'AI Product Design', desc: 'Interfaces for LLMs, agents, and intelligent workflows.', metric: 'CONFIDENCE 0.96' },
    { title: 'Design Systems & Tokens', desc: 'Scalable foundations that keep products coherent at scale.', metric: '200+ COMPONENTS' },
    { title: 'SaaS Dashboards', desc: 'Data-dense interfaces that surface signal, not noise.', metric: 'SIGNAL / NOISE HIGH' },
    { title: 'Landing Pages & Marketing', desc: 'Narrative-driven pages that convert intent into action.', metric: 'CONVERSION LAYER' },
    { title: 'Mobile App Design', desc: 'Touch-native experiences from onboarding to retention loops.', metric: 'PLATFORM NATIVE' },
    { title: 'Design Leadership & Strategy', desc: 'Building teams, processes, and culture that ship with clarity.', metric: '5 TEAMS LED' },
  ];

  const sizes = ['span 2', 'span 1', 'span 1', 'span 1', 'span 1', 'span 2'];

  return (
    <section data-screen-label="06 Skills" style={{ backgroundColor: '#1E1E1E', padding: '120px 64px', position: 'relative' }}>
      <Pagination label="CAPABILITIES" num="6" />
      <div style={{ marginBottom: 56 }}>
        <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(2.5rem, 5vw, 5rem)', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.0, color: '#FAF7F2', margin: 0 }}>
          What Raw UX builds<span style={{ color: '#C0452A' }}>.</span>
        </h2>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        {capabilities.map((c, i) => (
          <div key={i} style={{
            gridColumn: sizes[i],
            backgroundColor: '#2D3830',
            padding: density === 'restrained' ? '28px' : '32px',
            display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
            minHeight: density === 'dense' ? 200 : 160,
          }}>
            <div>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#6B6560', marginBottom: 12 }}>{c.title}</div>
              <div style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '0.9rem', lineHeight: 1.55, color: '#E5E5E5' }}>{c.desc}</div>
            </div>
            {density !== 'restrained' && (
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.65rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#C0452A', marginTop: 20 }}>{c.metric}</div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
};

/* ─── SECTION 7: TOOLS ─── */
const ToolsSection = ({ tweaks }) => {
  const density = tweaks.density;
  const designTools = ['Figma', 'Claude Design', 'Framer'];
  const engTools = ['Next.js', 'Supabase', 'Tailwind', 'Vercel', 'Claude Code', 'Claude API'];

  return (
    <section data-screen-label="07 Tools" style={{ backgroundColor: '#FAF7F2', padding: '120px 64px', position: 'relative' }}>
      <Pagination label="TOOLS & STACK" num="7" />
      <div style={{ display: 'flex', gap: 80 }}>
        <div style={{ flex: 1 }}>
          <Headline text="Instruments of the practice." />
          <div style={{ marginTop: 56 }}>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#C0452A', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}><Dot /> Design</div>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 48 }}>
              {designTools.map(t => (
                <div key={t} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.8rem', letterSpacing: '0.06em', color: '#1A1A1A', padding: '10px 18px', backgroundColor: '#F5F0E8' }}>{t}</div>
              ))}
            </div>

            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#C0452A', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}><Dot /> Engineering</div>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              {engTools.map(t => (
                <div key={t} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.8rem', letterSpacing: '0.06em', color: '#1A1A1A', padding: '10px 18px', backgroundColor: '#F5F0E8' }}>{t}</div>
              ))}
            </div>
          </div>
        </div>

        {density !== 'restrained' && (
          <div style={{ width: 280, flexShrink: 0, alignSelf: 'center' }}>
            <AnnotationCard label="TOOLS FOR DESIGN ENGINEERING" value={density === 'dense' ? 'RESEARCH TO PRODUCTION\nIN ONE PRACTICE' : undefined} dark={true} />
          </div>
        )}
      </div>
    </section>
  );
};

/* ─── SECTION 8: CONTACT ─── */
const ContactSection = () => {
  const links = [
    { label: 'Dribbble', href: '#' },
    { label: 'LinkedIn', href: '#' },
    { label: 'X', href: '#' },
  ];

  return (
    <section data-screen-label="08 Contact" style={{ backgroundColor: '#1E1E1E', padding: '120px 64px 80px', position: 'relative' }}>
      <Pagination label="CONTACT" num="8" />
      <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(2.5rem, 5vw, 5rem)', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.0, color: '#FAF7F2', margin: '0 0 32px 0' }}>
        Start a project<span style={{ color: '#C0452A' }}>.</span>
      </h2>
      <div style={{ display: 'flex', gap: 80, alignItems: 'flex-start' }}>
        <div>
          <a href="mailto:hello@rawux.studio" style={{ fontFamily: "'Public Sans', sans-serif", fontSize: '1.1rem', color: '#E5E5E5', textDecoration: 'none', borderBottom: '1px solid #6B6560' }}>hello@rawux.studio</a>
          <div style={{ display: 'flex', gap: 24, marginTop: 28 }}>
            {links.map(l => (
              <a key={l.label} href={l.href} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.75rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#6B6560', textDecoration: 'none', cursor: 'pointer' }}>{l.label}</a>
            ))}
          </div>
          <div style={{ marginTop: 40 }}>
            <BtnPrimary>Start a project</BtnPrimary>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ marginTop: 120, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderTop: '1px solid #2D3830', paddingTop: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: '1.8rem', color: '#FAF7F2', lineHeight: 1 }}>R <span style={{ color: '#C0452A' }}>/</span> U</div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.6rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#6B6560', lineHeight: 1.6 }}>
            Raw UX / Design Studio<br />Hyderabad, India
          </div>
        </div>
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '0.6rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#6B6560' }}>
          &copy; 2026 Raw UX
        </div>
      </div>
    </section>
  );
};

Object.assign(window, { ProcessSection, SkillsSection, ToolsSection, ContactSection });
